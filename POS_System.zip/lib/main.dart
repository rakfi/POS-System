import 'package:flutter/material.dart';

void main() {
  runApp(EnhancedPOSApp());
}

class EnhancedPOSApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'POS System',
      theme: ThemeData(
        primarySwatch: Colors.teal,
      ),
      home: POSHomePage(),
    );
  }
}

class POSHomePage extends StatefulWidget {
  @override
  _POSHomePageState createState() => _POSHomePageState();
}

class _POSHomePageState extends State<POSHomePage> {
  final List<Item> items = [
    Item(
        name: 'Burger',
        price: 500.00,
        icon: Icons.lunch_dining,
        color: Colors.orange),
    Item(
        name: 'Pizza',
        price: 800.00,
        icon: Icons.local_pizza,
        color: Colors.redAccent),
    Item(
        name: 'Pasta',
        price: 750.00,
        icon: Icons.ramen_dining,
        color: Colors.brown),
    Item(
        name: 'Fries',
        price: 300.00,
        icon: Icons.fastfood,
        color: Colors.amber),
  ];

  final Map<Item, int> cart = {};
  double discountPercentage = 0;
  double serviceChargePercentage = 10;

  void addItem(Item item) {
    setState(() {
      cart[item] = (cart[item] ?? 0) + 1;
    });
  }

  void removeItem(Item item) {
    setState(() {
      if (cart[item] != null && cart[item]! > 0) {
        cart[item] = cart[item]! - 1;
        if (cart[item] == 0) cart.remove(item);
      }
    });
  }

  double get subtotal {
    return cart.entries
        .map((entry) => entry.key.price * entry.value)
        .fold(0, (prev, amount) => prev + amount);
  }

  double get discount => subtotal * (discountPercentage / 100);
  double get serviceCharge => subtotal * (serviceChargePercentage / 100);
  double get total => subtotal - discount + serviceCharge;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('POS System'),
        backgroundColor: Colors.teal[700],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: items.length,
              itemBuilder: (context, index) {
                final item = items[index];
                return Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15.0),
                  ),
                  color: Colors.teal[50],
                  shadowColor: Colors.teal[200],
                  elevation: 8,
                  margin: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: item.color.withOpacity(0.8),
                      child: Icon(item.icon, color: Colors.white, size: 24),
                    ),
                    title: Text(
                      item.name,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.teal[900],
                        fontSize: 18,
                      ),
                    ),
                    subtitle: Text(
                      "\RS.${item.price.toStringAsFixed(2)}",
                      style: TextStyle(color: Colors.teal[800]),
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(Icons.remove_circle,
                              color: Colors.redAccent, size: 28),
                          onPressed: () => removeItem(item),
                        ),
                        Text(
                          '${cart[item] ?? 0}',
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        IconButton(
                          icon: Icon(Icons.add_circle,
                              color: Colors.green, size: 28),
                          onPressed: () => addItem(item),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          Divider(thickness: 2, color: Colors.teal[200]),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                buildSummaryRow('Subtotal', subtotal),
                buildSummaryRow(
                    'Discount (${discountPercentage.toStringAsFixed(1)}%)',
                    -discount),
                buildSummaryRow(
                    'Service Charge (${serviceChargePercentage.toStringAsFixed(1)}%)',
                    serviceCharge),
                SizedBox(height: 10),
                Divider(thickness: 2, color: Colors.teal[300]),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Total:",
                      style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                        color: Colors.teal[700],
                      ),
                    ),
                    Text(
                      "\RS.${total.toStringAsFixed(2)}",
                      style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                        color: Colors.teal[800],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: [
                buildPercentageInput(
                  label: 'Discount (%)',
                  value: discountPercentage,
                  onChanged: (value) {
                    setState(() {
                      discountPercentage = value;
                    });
                  },
                ),
                buildPercentageInput(
                  label: 'Service Charge (%)',
                  value: serviceChargePercentage,
                  onChanged: (value) {
                    setState(() {
                      serviceChargePercentage = value;
                    });
                  },
                ),
              ],
            ),
          ),
          SizedBox(height: 10),
        ],
      ),
    );
  }

  Widget buildSummaryRow(String label, double amount) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
          ),
          Text(
            "\RS.${amount.toStringAsFixed(2)}",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget buildPercentageInput({
    required String label,
    required double value,
    required Function(double) onChanged,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
        ),
        SizedBox(
          width: 100,
          child: TextFormField(
            initialValue: value.toStringAsFixed(1),
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              suffixText: '%',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8.0),
                borderSide: BorderSide(color: Colors.teal, width: 1.5),
              ),
              filled: true,
              fillColor: Colors.teal[50],
              contentPadding:
                  EdgeInsets.symmetric(vertical: 12, horizontal: 10),
            ),
            onChanged: (text) {
              onChanged(double.tryParse(text) ?? 0);
            },
          ),
        ),
      ],
    );
  }
}

class Item {
  final String name;
  final double price;
  final IconData icon;
  final Color color;

  Item(
      {required this.name,
      required this.price,
      required this.icon,
      required this.color});
}
