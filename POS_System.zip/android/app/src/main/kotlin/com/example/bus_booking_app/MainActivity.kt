package com.example.bus_booking_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
